using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class suscribeDoor : MonoBehaviour
{
    [SerializeField] MultipleBoolRecivers boolReciver;
    private void Awake()
    {
       boolReciver =  GetComponent<MultipleBoolRecivers>();
    }
    void Start()
    {
            //if(GameManager.Instance != null)
            //{
            //    GameManager.Instance.getCoin += boolReciver.OnButtonValueChanged;
            //}
    }
    private void OnEnable()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.getCoin += boolReciver.OnButtonValueChanged;
        }
    }
    private void OnDisable()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.getCoin -= boolReciver.OnButtonValueChanged;
        }
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.getCoin -= boolReciver.OnButtonValueChanged;
        }
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
