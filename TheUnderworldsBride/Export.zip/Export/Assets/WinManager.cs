using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WinManager : MonoBehaviour
{
    [SerializeField] GameObject button;

    private void Start()
    {
        GameManager.Instance.UIManage.SetFirstObject(button);
    }
    public void BackToMainMenu()
    {
        GameManager.Instance.MainMenu();
    }
}
