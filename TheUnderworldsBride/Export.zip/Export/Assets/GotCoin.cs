using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GotCoin : MonoBehaviour
{
    public void GetCoin()
    {
        if (GameManager.Instance != null )GameManager.Instance.GetCoin();
    }
}
